


public class Main {
	
	
	

	
    public static void main(String[] args) {
        UserInterface kayttoliittyma = new UserInterface();
        kayttoliittyma.run();
    }
		
		


        }








